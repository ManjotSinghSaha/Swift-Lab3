//
//  SecondViewController.swift
//  Manjot Singh Saha_COMP2125-Sec001_Lab03
//
//  Created by Manjot Singh Saha on 2020-07-14.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var txtProjectName: UITextField!
    
    @IBOutlet weak var txtDuration: UITextField!
    
    @IBOutlet weak var txtCity: UITextField!
    
    @IBOutlet weak var lblOutput: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnSubmit(_ sender: UIButton) {
        lblOutput.text! = "Project Name: " + txtProjectName.text! + "   Duartion: " + txtDuration.text! + "   City: " + txtCity.text!
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
