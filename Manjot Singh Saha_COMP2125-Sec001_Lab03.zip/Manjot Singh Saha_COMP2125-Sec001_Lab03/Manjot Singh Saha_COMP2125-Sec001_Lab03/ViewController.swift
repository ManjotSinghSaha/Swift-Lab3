//
//  ViewController.swift
//  Manjot Singh Saha_COMP2125-Sec001_Lab03
//
//  Created by Manjot Singh Saha on 2020-07-14.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var txtUserName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnLogin(_ sender: UIButton) {
    }
    
}

